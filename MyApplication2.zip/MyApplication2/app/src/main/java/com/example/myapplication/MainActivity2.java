package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

public class MainActivity2 extends AppCompatActivity {

    TextView text;
    TextView points_value;
    Button txns,txn_detail,redmpt,family;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        text = findViewById(R.id.user);
        txns = findViewById(R.id.txn);
        txn_detail = findViewById(R.id.txn_details);
        redmpt = findViewById(R.id.redmpt_details);
        family = findViewById(R.id.family_percent);

        ImageView imageView=findViewById(R.id.imageView);
        Intent intent = getIntent();
        String cid = intent.getStringExtra("name");

        RequestQueue queue = Volley.newRequestQueue(MainActivity2.this);
        String url="http://10.0.2.2:8080/loyaltyfirst/Info.jsp?cid="+cid;
        //Toast.makeText(MainActivity2.this, url, Toast.LENGTH_SHORT).show();
        StringRequest request = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String s) {
                if (s.trim().equals("No")){
                    Toast.makeText(MainActivity2.this,"Invalid Username",Toast.LENGTH_LONG).show();
                }else{
                    String[] result=s.trim().split(",");
                    String name = result[0];
                    Integer points = Integer.parseInt(result[1]);
                    text.setText(name);

                    points_value = findViewById(R.id.points);
                    points_value.setText(+points+" Reward Points");

                }
            }
        },null);
        queue.add(request);

        String url2="http://10.0.2.2:8080/loyaltyfirst/images/"+cid+".jpg";
        String image_url = url2.replaceAll("\\s+","");

        Toast.makeText(MainActivity2.this, image_url, Toast.LENGTH_LONG).show();
        ImageRequest request2 = new ImageRequest(image_url, new Response.Listener<Bitmap>() {
            @Override
            public void onResponse(Bitmap bitmap) {
                imageView.setImageBitmap(bitmap);
            }
        },0,0,null,null);
        queue.add(request2);

        txns.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity2.this,MainActivity3.class);
                intent.putExtra("name",cid);
                startActivity(intent);
            }
        });

        txn_detail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity2.this,MainActivity4.class);
                intent.putExtra("name",cid);
                startActivity(intent);
            }
        });

        redmpt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity2.this,MainActivity5.class);
                intent.putExtra("name",cid);
                startActivity(intent);
            }
        });

        family.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity2.this,MainActivity6.class);
                intent.putExtra("name",cid);
                startActivity(intent);
            }
        });
    }
}