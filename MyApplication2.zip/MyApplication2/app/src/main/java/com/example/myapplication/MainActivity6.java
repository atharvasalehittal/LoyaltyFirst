package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.ArrayList;

public class MainActivity6 extends AppCompatActivity {

    Spinner spinner;
    TextView txns;
    Button family_point;
    int points;
    String familyid;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);
        spinner = findViewById(R.id.spinner);
        RequestQueue queue = Volley.newRequestQueue(MainActivity6.this);
        ArrayList<String> list = new ArrayList<String>();
        txns = findViewById(R.id.transactions);
        family_point = findViewById(R.id.family_points);

        Intent intent = getIntent();
        String name = intent.getStringExtra("name");
        String url="http://10.0.2.2:8080/loyaltyfirst/Transactions.jsp?cid="+name;
        Toast.makeText(MainActivity6.this, url, Toast.LENGTH_SHORT).show();

        StringRequest request3 = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String s) {
                if (s.trim().equals("No")){
                    Toast.makeText(MainActivity6.this,"Invalid Username",Toast.LENGTH_LONG).show();
                }else{
                    String[] result = s.trim().split("[#,]");
                    String output = "";
                    int j=0;
                    for(int i=0;i<result.length;i=i+4){
                        list.add(result[i]);
                    }
                    ArrayAdapter<String> newArrayAdapter = new ArrayAdapter<String>(MainActivity6.this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item,list);
                    newArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spinner.setAdapter(newArrayAdapter);

                    spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                            //Toast.makeText(MainActivity6.this,"Item selected: "+list.get(i),Toast.LENGTH_SHORT).show();
                            String url="http://10.0.2.2:8080/loyaltyfirst/SupportFamilyIncrease.jsp?cid="+name+"&tref="+list.get(i);
                            StringRequest request3 = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                                @Override
                                public void onResponse(String s) {
                                    if (s.trim().equals("No")){
                                        Toast.makeText(MainActivity6.this,"Invalid Transaction Id",Toast.LENGTH_LONG).show();
                                    }else {
                                        String[] result = s.trim().split("#");
                                        String[] value = s.trim().split("[#,]");
                                        familyid = value[0];
                                        points = Integer.valueOf(value[2]);
                                        //Toast.makeText(MainActivity3.this, result[0], Toast.LENGTH_SHORT).show();
                                        String output = "";
                                        for(int i=0;i<result.length;i++){
                                            output += result[i] + "\n";
                                        }
                                        txns.setText(output);
                                    }
                                }
                            },null);
                            queue.add(request3);
                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> adapterView) {

                        }
                    });
                }
            }
        },null);
        queue.add(request3);

        family_point.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RequestQueue queue = Volley.newRequestQueue(MainActivity6.this);
                String url="http://10.0.2.2:8080/loyaltyfirst/FamilyIncrease.jsp?fid="+familyid+"&cid="+name+"&npoints="+points;
                StringRequest request4 = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String s) {
                        if (s.trim().equals("No")){
                            Toast.makeText(MainActivity6.this,"No users with the family id",Toast.LENGTH_LONG).show();
                        }else{
                            Toast.makeText(MainActivity6.this,0.3*points+" points added to the members of family id "+familyid,Toast.LENGTH_SHORT).show();
                        }
                    }
                },null);
                queue.add(request4);
            }
        });
    }
}