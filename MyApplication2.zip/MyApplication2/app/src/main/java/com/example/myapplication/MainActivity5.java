package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.ArrayList;

public class MainActivity5 extends AppCompatActivity {

    Spinner spinner;
    TextView prize;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);

        spinner = findViewById(R.id.spinner);
        prize = findViewById(R.id.prize_details);
        RequestQueue queue = Volley.newRequestQueue(MainActivity5.this);
        ArrayList<String> list = new ArrayList<String>();

        Intent intent = getIntent();
        String name = intent.getStringExtra("name");
        String url="http://10.0.2.2:8080/loyaltyfirst/PrizeIds.jsp?cid="+name;
        Toast.makeText(MainActivity5.this, url, Toast.LENGTH_SHORT).show();

        StringRequest request = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String s) {
                if (s.trim().equals("No")){
                    Toast.makeText(MainActivity5.this,"Invalid Username",Toast.LENGTH_LONG).show();
                }else{
                    String[] result = s.trim().split("#");
                    String output = "";
                    int j=0;
                    for(int i=0;i<result.length;i=i+4){
                        list.add(result[i]);
                    }
                    ArrayAdapter<String> newArrayAdapter = new ArrayAdapter<String>(MainActivity5.this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item,list);
                    newArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spinner.setAdapter(newArrayAdapter);
                    spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                            //Toast.makeText(MainActivity5.this,"Item selected: "+list.get(i),Toast.LENGTH_SHORT).show();
                            String url="http://10.0.2.2:8080/loyaltyfirst/RedemptionDetails.jsp?&prizeid="+list.get(i)+"&cid="+name;
                            StringRequest request3 = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                                @Override
                                public void onResponse(String s) {
                                    if (s.trim().equals("No")){
                                        Toast.makeText(MainActivity5.this,"Invalid Transaction Id",Toast.LENGTH_LONG).show();
                                    }else {
                                        String[] result = s.trim().split("#");
                                        //Toast.makeText(MainActivity3.this, result[0], Toast.LENGTH_SHORT).show();
                                        String output = "";
                                        for(int i=0;i<result.length;i++){
                                            output += result[i] + "\n";
                                        }
                                        prize.setText(output);
                                    }
                                }
                            },null);
                            queue.add(request3);
                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> adapterView) {

                        }
                    });
                }
            }
        },null);
        queue.add(request);
    }
}