package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

public class MainActivity extends AppCompatActivity {

    private EditText userName,password;
    private Button login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        userName = findViewById(R.id.idEdtUserName);
        password = findViewById(R.id.idEdtPassword);
        login = findViewById(R.id.idBtnLogin);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = userName.getText().toString();
                String passwd_user = password.getText().toString();

                if(TextUtils.isEmpty(username) && TextUtils.isEmpty(passwd_user)){
                    Toast.makeText(MainActivity.this,"Please enter username and password",Toast.LENGTH_SHORT).show();
                }

                RequestQueue queue = Volley.newRequestQueue(MainActivity.this);
                String url="http://10.0.2.2:8080/loyaltyfirst/login?user="+username+"&pass="+passwd_user;
                //Toast.makeText(MainActivity.this,url,Toast.LENGTH_LONG).show();
                StringRequest request = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String s) {
                        //Toast.makeText(MainActivity.this,s.trim(),Toast.LENGTH_LONG).show();
                        if(s.trim().equals("No")){
                            Toast.makeText(MainActivity.this,"Invalid Username or Password",Toast.LENGTH_LONG).show();
                        }else{
                            //Toast.makeText(MainActivity.this,"Login Success",Toast.LENGTH_SHORT).show();
                            String[] result=s.trim().split(":");
                            //Toast.makeText(MainActivity.this,result[1],Toast.LENGTH_LONG).show();
                            String name = result[1];
                            //Toast.makeText(MainActivity.this, name, Toast.LENGTH_SHORT).show();

                            Intent intent = new Intent(MainActivity.this,MainActivity2.class);
                            intent.putExtra("name",name);
                            startActivity(intent);
                        }
                    }
                },null);
                queue.add(request);
            }
        });
    }
}