package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

public class MainActivity3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        RequestQueue queue = Volley.newRequestQueue(MainActivity3.this);
        TextView txns = findViewById(R.id.txns);
        Intent intent = getIntent();
        String name = intent.getStringExtra("name");
        String url="http://10.0.2.2:8080/loyaltyfirst/Transactions.jsp?cid="+name;
        Toast.makeText(MainActivity3.this, url, Toast.LENGTH_SHORT).show();
        StringRequest request3 = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String s) {
                if (s.trim().equals("No")){
                    Toast.makeText(MainActivity3.this,"Invalid Username",Toast.LENGTH_LONG).show();
                }else {
                    String[] result = s.trim().split("#");
                    //Toast.makeText(MainActivity3.this, result[0], Toast.LENGTH_SHORT).show();
                    String output = "";
                    for(int i=0;i<result.length;i++){
                        output += result[i] + "\n";
                    }
                    txns.setText(output);
                }
            }
        },null);
        queue.add(request3);
    }
}