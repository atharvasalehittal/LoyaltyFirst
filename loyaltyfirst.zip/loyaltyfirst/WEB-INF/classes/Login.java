
import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.sql.*;

@WebServlet("/login")
public class Login extends HttpServlet{
    
    public void doGet(HttpServletRequest request, HttpServletResponse response){
        try{
            PrintWriter out = response.getWriter();
            String user = request.getParameter("user");
            String pswd = request.getParameter("pass");
            
            DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
            String url = "jdbc:oracle:thin:@artemis.vsnet.gmu.edu:1521/vse18c.vsnet.gmu.edu";
            Connection con = DriverManager.getConnection(url,"asalehit","oodakebo");
            PreparedStatement st = con.prepareStatement("select * from login where username=? and passwd=?");
            st.setString(1, user);
            st.setString(2, pswd);
            ResultSet rs = st.executeQuery();
            
            if(rs.next()){
                if(user.equals(rs.getString(2)) && pswd.equals(rs.getString(3)))
                    out.print("Yes "+"Cid: "+rs.getString(1));
                else
                    out.print("No");
            }else
                out.println("No");
            con.close();
        }catch(Exception ex){
        }
    }
}
